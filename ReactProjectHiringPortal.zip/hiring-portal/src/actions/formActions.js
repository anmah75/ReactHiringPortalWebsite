// import axios from 'axios';

// export const submitForm = (formData) => {
//     return (dispatch) => {
//         axios.post('/api/submit', formData)
//             .then(response => {
//                 dispatch({
//                     type: 'SUBMIT_FORM',
//                     payload: formData,
//                 });
//             })
//             .catch(error => {
//                 console.error('There was an error submitting the form!', error);
//             });
//     };
// };
