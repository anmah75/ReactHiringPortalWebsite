// const initialState = {
//     formData: {},
//     submitted: false,
// };

// const formReducer = (state = initialState, action) => {
//     switch (action.type) {
//         case 'SUBMIT_FORM':
//             return {
//                 ...state,
//                 formData: action.payload,
//                 submitted: true,
//             };
//         default:
//             return state;
//     }
// };

// export default formReducer;
